# Extensão Auto Login GrhNet

Esta extensão foi criada para automatizar o login no portal GrhNet da Barbosa.

## Como usar:

1.  **Descompacte** o arquivo `.zip` em uma pasta no seu computador.
2.  Abra o arquivo `content.js` em um editor de texto (como o Bloco de Notas ou VS Code).
3.  Localize as variáveis `USUARIO` e `SENHA` no topo do arquivo e preencha com seus dados.
4.  Salve o arquivo.
5.  No seu navegador (Chrome ou Edge), acesse: `chrome://extensions/`
6.  Ative o **Modo do desenvolvedor** (canto superior direito).
7.  Clique em **Carregar sem compactação** e selecione a pasta onde você descompactou os arquivos.
8.  Pronto! Agora, sempre que você acessar o site da Barbosa, o login será feito automaticamente.

**Nota:** Se o site mudar os nomes dos campos, você precisará atualizar os seletores no arquivo `content.js`.

// ==========================================================================
// CONFIGURAÇÃO: PREENCHA SEUS DADOS ABAIXO
// ==========================================================================
const USUARIO = "57903977865";
const SENHA = "samamodz";
// ==========================================================================

function realizarLogin() {
    const campoUsuario = document.getElementById("txtIdentificacao");
    const campoSenha = document.getElementById("txtSenha");
    const botaoLogin = document.getElementById("Button1");

    if (campoUsuario && campoSenha && botaoLogin) {
        // Preenche os campos
        campoUsuario.value = USUARIO;
        campoSenha.value = SENHA;

        // Pequeno atraso para garantir que o preenchimento foi processado
        setTimeout(() => {
            console.log("Realizando login automático...");
            botaoLogin.click();
        }, 500);
    } else {
        console.log("Campos de login não encontrados. Verifique se você está na página correta.");
    }
}

// Executa a função assim que a página carregar
if (document.readyState === "complete" || document.readyState === "interactive") {
    realizarLogin();
} else {
    window.addEventListener("DOMContentLoaded", realizarLogin);
}

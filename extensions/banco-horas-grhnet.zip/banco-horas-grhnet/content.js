/**
 * Banco de Horas - GRHNet (Versão Refatorada)
 * Botão flutuante + popup de saldo com melhorias de robustez e UX.
 */

(function() {
  'use strict';

  /* ─────────────────────────────────────────────
     CONFIGURAÇÕES E CONSTANTES
  ───────────────────────────────────────────── */

  const CONFIG = {
    RESET_DAY: 1,
    TABLE_ID: 'ctl00_ContentPlaceHolder1_gvEspelho',
    POPUP_ID: 'banco-horas-popup',
    ROOT_ID: 'bh-root',
    COLORS: {
      POSITIVE_BG: '#eafaf1',
      POSITIVE_BORDER: '#27ae60',
      POSITIVE_TEXT: '#1a7a4a',
      NEGATIVE_BG: '#fdf2f0',
      NEGATIVE_BORDER: '#e74c3c',
      NEGATIVE_TEXT: '#c0392b',
      PRIMARY: '#2c3e50',
      OVERLAY: 'rgba(0,0,0,0.55)'
    }
  };

  /* ─────────────────────────────────────────────
     BASE TIPOGRÁFICA (1rem = 10px)
  ───────────────────────────────────────────── */

  const injectBaseStyles = () => {
    const style = document.createElement("style");
    style.textContent = `
      #${CONFIG.ROOT_ID} { font-size: 62.5%; }
    `;
    document.head.appendChild(style);
  };

  /* ─────────────────────────────────────────────
     UTILITÁRIOS
  ───────────────────────────────────────────── */

  /**
   * Converte uma string de tempo (HH:MM) em minutos totais.
   * @param {string} t - String de tempo.
   * @returns {number|null} Minutos totais ou null se inválido.
   */
  function timeToMinutes(t) {
    if (!t || !t.includes(':')) return null;
    const [h, m] = t.trim().split(':').map(part => parseInt(part, 10));
    return (isNaN(h) || isNaN(m)) ? null : h * 60 + m;
  }

  /**
   * Calcula a duração em minutos entre dois horários.
   * @param {string} ent - Horário de entrada.
   * @param {string} sai - Horário de saída.
   * @returns {number} Duração em minutos.
   */
  function calcPeriod(ent, sai) {
    const entMin = timeToMinutes(ent);
    const saiMin = timeToMinutes(sai);
    if (entMin === null || saiMin === null) return 0;
    let duration = saiMin - entMin;
    if (duration < 0) duration += 1440; // 24 * 60
    return duration;
  }

  /**
   * Converte minutos totais em uma string formatada (+/-HH:MM).
   * @param {number} totalMinutes - Minutos totais.
   * @returns {string} String formatada.
   */
  function minutesToStr(totalMinutes) {
    /*more or less*/
    const sign = totalMinutes >= 0 ? '' : '-';
    const abs = Math.abs(totalMinutes);
    const h = Math.floor(abs / 60);
    const m = abs % 60;
    return `${sign}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  function getSpanText(parent, suffix) {
    const span = parent.querySelector(`[id$="${suffix}"]`);
    return span ? span.textContent.trim() : '';
  }

  function calcTableMinutes(table, prefix) {
    if (!table) return 0;
    let total = 0;
    // Melhoria: buscar todos os spans de entrada/saída dinamicamente se possível, 
    // ou manter o loop se a estrutura for fixa.
    for (let i = 1; i <= 4; i++) {
      const ent = getSpanText(table, `lblDesc${prefix}Ent${i}`);
      const sai = getSpanText(table, `lblDesc${prefix}Sai${i}`);
      total += calcPeriod(ent, sai);
    }
    return total;
  }

  function parseRowDate(dateText) {
    const match = dateText.match(/(\d{2})\/(\d{2})\/(\d{4})/);
    if (!match) return null;
    const [, d, m, y] = match;
    return new Date(parseInt(y), parseInt(m) - 1, parseInt(d));
  }

  /**
   * Obtém a data de início do período de apuração.
   * @returns {Date} Data de reset normalizada.
   */
  function getResetDate() {
    const today = new Date();
    const day = today.getDate();
    const month = today.getMonth();
    const year = today.getFullYear();

    let resetDate;
    if (day >= CONFIG.RESET_DAY) {
      resetDate = new Date(year, month, CONFIG.RESET_DAY);
    } else {
      const prevMonth = month === 0 ? 11 : month - 1;
      const prevYear = month === 0 ? year - 1 : year;
      resetDate = new Date(prevYear, prevMonth, CONFIG.RESET_DAY);
    }
    resetDate.setHours(0, 0, 0, 0);
    return resetDate;
  }

  /* ─────────────────────────────────────────────
     LÓGICA PRINCIPAL
  ───────────────────────────────────────────── */

  function calcBancoHoras() {
    const table = document.getElementById(CONFIG.TABLE_ID);
    if (!table) {
      console.warn(`Tabela com ID ${CONFIG.TABLE_ID} não encontrada.`);
      return null;
    }

    const resetDate = getResetDate();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const rows = table.querySelectorAll('tbody > tr.cellEspelho');
    let totalMinutes = 0;
    const details = [];

    rows.forEach((tr) => {
      const tds = tr.querySelectorAll(':scope > td');
      if (tds.length < 5) return;

      const dateText = tds[0].textContent.trim();
      const rowDate = parseRowDate(dateText);
      if (!rowDate) return;

      // Normaliza rowDate para comparação
      rowDate.setHours(0, 0, 0, 0);
    //  if (rowDate < resetDate || rowDate >= today) return;

      const planText = tds[1].textContent.trim();
      const ocoText = tds[4].textContent.trim();

      if (planText.toLowerCase().includes('folga') || planText === '' || ocoText.toLowerCase().includes('abonado')) return;

      const planTable = tds[1].querySelector('table');
      const realTable = tds[2].querySelector('table');

      const planMinutes = calcTableMinutes(planTable, 'Plan');
      const realMinutes = calcTableMinutes(realTable, 'Real');

      if (planMinutes === 0 || realMinutes === 0) return;

      const diff = realMinutes - planMinutes;
      totalMinutes += diff;

      details.push({
        date: dateText,
        planned: planMinutes,
        actual: realMinutes,
        diff
      });
    });

    return { totalMinutes, rowCount: details.length, resetDate, details };
  }

  /* ─────────────────────────────────────────────
     POPUP E UI
  ───────────────────────────────────────────── */

  function createPopup(result) {
    const existing = document.getElementById(CONFIG.POPUP_ID);
    if (existing) existing.remove();

    const { totalMinutes, details } = result;
    const isPositive = totalMinutes >= 0;
    const saldoStr = minutesToStr(totalMinutes);

    const overlay = document.createElement("div");
    overlay.id = CONFIG.POPUP_ID;
    overlay.innerHTML = `
      <div id="${CONFIG.ROOT_ID}">
        <div class="bh-overlay">
          <div class="bh-card" role="dialog" aria-labelledby="bh-title">
            <button class="bh-close" aria-label="Fechar">✕</button>
            <div id="bh-title" class="bh-title">⏱ Banco de Horas</div>
            <div class="bh-saldo-box ${isPositive ? 'pos' : 'neg'}">
              <div class="bh-saldo-label">Saldo atual</div>
              <div class="bh-saldo-value">${saldoStr}</div>
            </div>
            <button class="bh-details-btn">Ver detalhes</button>
            <div class="bh-details" style="display:none;"></div>
          </div>
        </div>
      </div>
    `;

    const style = document.createElement("style");
    style.textContent = `
      .bh-overlay {
        position: fixed; inset: 0; background: ${CONFIG.COLORS.OVERLAY};
        z-index: 999999; display: flex; align-items: center; justify-content: center;
        font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      }
      .bh-card {
        background: #fff; border-radius: 1.6rem; padding: 3rem; width: 36rem;
        box-shadow: 0 0.8rem 4rem rgba(0,0,0,0.28); position: relative;
      }
      .bh-close {
        position: absolute; top: 1.5rem; right: 1.5rem; border: none;
        background: none; font-size: 2rem; cursor: pointer; color: #666;
      }
      .bh-title { font-size: 1.8rem; font-weight: 700; margin-bottom: 1.5rem; color: ${CONFIG.COLORS.PRIMARY}; }
      .bh-saldo-box { padding: 2rem; border-radius: 1.2rem; text-align: center; border: 0.2rem solid; }
      .bh-saldo-box.pos { background: ${CONFIG.COLORS.POSITIVE_BG}; border-color: ${CONFIG.COLORS.POSITIVE_BORDER}; color: ${CONFIG.COLORS.POSITIVE_TEXT}; }
      .bh-saldo-box.neg { background: ${CONFIG.COLORS.NEGATIVE_BG}; border-color: ${CONFIG.COLORS.NEGATIVE_BORDER}; color: ${CONFIG.COLORS.NEGATIVE_TEXT}; }
      .bh-saldo-label { font-size: 1.3rem; margin-bottom: 0.5rem; opacity: 0.8; }
      .bh-saldo-value { font-size: 4.2rem; font-weight: 800; }
      .bh-details-btn {
        margin-top: 1.5rem; width: 100%; padding: 1.2rem; border-radius: 0.8rem;
        border: 1px solid #ddd; background: #f9f9f9; cursor: pointer; font-size: 1.4rem; transition: background 0.2s;
      }
      .bh-details-btn:hover { background: #f0f0f0; }
      .bh-details { margin-top: 1.5rem; max-height: 20rem; overflow-y: auto; font-size: 1.2rem; border-top: 1px solid #eee; padding-top: 1rem; }
      .bh-detail-row { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px thin #f5f5f5; }
    `;
    document.head.appendChild(style);

    const detailsDiv = overlay.querySelector(".bh-details");
    details.forEach(d => {
      const row = document.createElement("div");
      row.className = "bh-detail-row";
      row.innerHTML = `<span>${d.date}</span> <strong>${minutesToStr(d.diff)}</strong>`;
      detailsDiv.appendChild(row);
    });

    const closePopup = () => overlay.remove();
    overlay.querySelector(".bh-close").onclick = closePopup;
    overlay.onclick = e => { if (e.target === overlay.querySelector('.bh-overlay')) closePopup(); };

    // Fechar com ESC
    const escHandler = (e) => { if (e.key === 'Escape') { closePopup(); document.removeEventListener('keydown', escHandler); } };
    document.addEventListener('keydown', escHandler);

    overlay.querySelector(".bh-details-btn").onclick = (e) => {
      const isHidden = detailsDiv.style.display === 'none';
      detailsDiv.style.display = isHidden ? 'block' : 'none';
      e.target.textContent = isHidden ? 'Ocultar detalhes' : 'Ver detalhes';
    };

    document.body.appendChild(overlay);
  }

  function createFloatingButton() {
    const btn = document.createElement("button");
    btn.textContent = "⏱";
    btn.title = "Calcular Banco de Horas";
    btn.style.cssText = `
      position: fixed;
      bottom: 2.4rem;
      right: 2.4rem;
      width: 5.6rem;
      height: 5.6rem;
      border-radius: 50%; 
      border: none;
      background: ${CONFIG.COLORS.PRIMARY}; 
      color: white;
      font-size: 2.4rem;
      cursor: pointer; 
      z-index: 999999;
      box-shadow: 0 0.6rem 1.8rem rgba(0,0,0,0.25); 
      transition: transform 0.2s, background 0.2s;
    `;
    btn.onmouseover = () => btn.style.transform = 'scale(1.1)';
    btn.onmouseout = () => btn.style.transform = 'scale(1)';

    btn.onclick = () => {
      const result = calcBancoHoras();
      if (result) createPopup(result);
      else alert("Não foi possível encontrar os dados do banco de horas nesta página.");
    };

    document.body.appendChild(btn);
  }

  /* ─────────────────────────────────────────────
     INICIALIZAÇÃO
  ───────────────────────────────────────────── */

  const init = () => {
    injectBaseStyles();
    setTimeout(createFloatingButton, 500);
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();

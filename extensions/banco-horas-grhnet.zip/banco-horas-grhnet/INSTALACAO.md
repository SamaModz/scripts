# Banco de Horas GRHNet — Guia de Instalação

## O que faz esta extensão?

Ao acessar a página de **Espelho de Presença** do GRHNet, um pop-up é exibido automaticamente mostrando o saldo atual do seu banco de horas no formato `+HH:MM` (positivo) ou `-HH:MM` (negativo).

**Regras de cálculo:**
- O banco de horas é zerado todo **dia 21** de cada mês.
- Apenas os dias a partir do dia 21 mais recente são considerados.
- Dias de **folga** são ignorados.
- O dia **atual** (sem registro completo) é ignorado.
- Turnos noturnos com **virada de meia-noite** são tratados corretamente.

---

## Instalação no Google Chrome (ou Edge/Brave)

### Passo 1 — Extrair o arquivo ZIP

Extraia o arquivo `banco-horas-grhnet.zip` em uma pasta de sua preferência.  
Exemplo: `C:\Extensoes\banco-horas-extension\`

### Passo 2 — Abrir o gerenciador de extensões

1. Abra o **Google Chrome**
2. Na barra de endereços, digite: `chrome://extensions`
3. Pressione **Enter**

### Passo 3 — Ativar o modo desenvolvedor

No canto superior direito da página de extensões, ative a chave **"Modo do desenvolvedor"** (Developer mode).

### Passo 4 — Carregar a extensão

1. Clique no botão **"Carregar sem compactação"** (Load unpacked)
2. Navegue até a pasta extraída (`banco-horas-extension`)
3. Clique em **"Selecionar pasta"**

### Passo 5 — Pronto!

A extensão **"Banco de Horas - GRHNet"** aparecerá na lista. Acesse o site:

```
https://barbosa.dtm.com.br/GrhNet/Employees/PontoEletronico/frmEspelhoPresenca.aspx
```

O pop-up com o saldo será exibido automaticamente!

---

## Instalação no Firefox

> O Firefox utiliza Manifest V2. Esta extensão usa Manifest V3 (compatível com Chrome/Edge/Brave).  
> Para Firefox, é necessária uma adaptação adicional. Recomenda-se usar Chrome, Edge ou Brave.

---

## Solução de problemas

| Problema | Solução |
|---|---|
| Pop-up não aparece | Recarregue a página (F5) e aguarde alguns segundos |
| "Tabela não encontrada" | Verifique se está na página correta do espelho de presença |
| Saldo zerado | Verifique se há registros no período (desde o dia 21) |
| Extensão não carrega | Confirme que selecionou a pasta correta (com `manifest.json`) |

---

## Atualizar a extensão

Para atualizar, substitua os arquivos na pasta e clique em **"Atualizar"** (ícone de seta circular) na página `chrome://extensions`.

# YouTube AdRemover Pro

Esta é uma extensão leve para navegador projetada para remover anúncios do YouTube e pular automaticamente propagandas em vídeo.

## Funcionalidades
- **Pulo Automático:** Clica no botão "Pular Anúncio" assim que ele aparece.
- **Aceleração de Anúncios:** Se um anúncio não puder ser pulado, ele é acelerado em 16x e silenciado.
- **Bloqueio Cosmético:** Oculta banners, anúncios de barra lateral e anúncios no feed.
- **Anti-Anti-Adblock:** Tenta remover os avisos do YouTube sobre o uso de bloqueadores de anúncios.

## Como Instalar (Chrome / Edge / Brave)
1. Baixe e extraia o arquivo ZIP da extensão.
2. Abra o seu navegador e vá para `chrome://extensions/`.
3. Ative o **Modo do Desenvolvedor** (Developer Mode) no canto superior direito.
4. Clique em **Carregar sem compactação** (Load unpacked).
5. Selecione a pasta onde você extraiu os arquivos da extensão.
6. Pronto! A extensão aparecerá na sua lista e começará a funcionar no YouTube.

## Como Instalar (Firefox)
1. Abra o Firefox e vá para `about:debugging#/runtime/this-firefox`.
2. Clique em **Carregar Extensão Temporária** (Load Temporary Add-on).
3. Selecione o arquivo `manifest.json` dentro da pasta da extensão.
*Nota: No Firefox, extensões temporárias são removidas ao fechar o navegador, a menos que sejam instaladas via conta de desenvolvedor.*

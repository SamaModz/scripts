const skipAds = () => {
    // 1. Clicar no botão de pular anúncio se ele existir
    const skipButton = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
    if (skipButton) {
        skipButton.click();
        console.log("Anúncio pulado via botão.");
    }

    // 2. Remover avisos de anti-adblock (overlays)
    const overlays = document.querySelectorAll('yt-enforcement-message-view-model, ytd-enforcement-message-view-model');
    overlays.forEach(overlay => {
        overlay.remove();
        console.log("Aviso de anti-adblock removido.");
        // Tentar retomar o vídeo se ele foi pausado pelo aviso
        const playButton = document.querySelector('.ytp-play-button');
        if (playButton && playButton.title.includes('Play')) {
            playButton.click();
        }
    });

    // 3. Lógica para acelerar anúncios que não podem ser pulados imediatamente
    const videoPlayer = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing, .ad-interrupting');
    
    if (adShowing && videoPlayer) {
        // Se for um anúncio, silencia e acelera 16x
        videoPlayer.muted = true;
        videoPlayer.playbackRate = 16;
        
        // Opcional: pular para o final do vídeo do anúncio
        if (isFinite(videoPlayer.duration)) {
            videoPlayer.currentTime = videoPlayer.duration;
        }
        console.log("Anúncio detectado: acelerando e silenciando.");
    }
};

// Executar a função periodicamente e quando houver mudanças na página
const observer = new MutationObserver(() => {
    skipAds();
});

// Iniciar a observação quando o corpo da página estiver disponível
const startObserver = () => {
    const targetNode = document.body;
    if (targetNode) {
        observer.observe(targetNode, { childList: true, subtree: true });
        // Execução inicial
        skipAds();
    } else {
        // Tentar novamente em breve se o body ainda não carregou
        setTimeout(startObserver, 100);
    }
};

startObserver();

// Monitorar também o elemento de vídeo especificamente para mudanças de estado
setInterval(skipAds, 500);

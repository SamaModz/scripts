document.addEventListener('DOMContentLoaded', () => {
  const toggleButton = document.getElementById('toggleButton');

  // Initial state (assuming AdBlock is active by default)
  let adblockActive = true;
  toggleButton.textContent = 'Desativar AdBlock';

  toggleButton.addEventListener('click', () => {
    adblockActive = !adblockActive;
    if (adblockActive) {
      toggleButton.textContent = 'Desativar AdBlock';
      // Logic to enable adblock rules
      console.log('AdBlock Ativado');
      // In a real extension, you would re-enable declarativeNetRequest rules here
    } else {
      toggleButton.textContent = 'Ativar AdBlock';
      // Logic to disable adblock rules
      console.log('AdBlock Desativado');
      // In a real extension, you would disable declarativeNetRequest rules here
    }
  });
});

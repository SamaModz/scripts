const adDomains = [
  "cdn.trafficbass.com",
  "acscdn.com",
  "retapedamidase.com",
  "salseprudely.com",
  "paupsoborofoow.net",
  "googletagmanager.com",
  "static.cloudflareinsights.com"
];

chrome.runtime.onInstalled.addListener(() => {
  const rules = adDomains.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: 'block' },
    condition: { 
      urlFilter: `||${domain}^`, 
      resourceTypes: ['main_frame', 'sub_frame', 'script', 'image', 'stylesheet', 'xmlhttprequest'] 
    }
  }));

  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: rules,
    removeRuleIds: rules.map(r => r.id)
  });
});

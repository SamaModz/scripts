// Função para criar e injetar o modal na página
function createModal() {
  if (document.getElementById('insta-tracker-modal')) return;

  const modal = document.createElement('div');
  modal.id = 'insta-tracker-modal';
  modal.style.cssText = `
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    width: 420px; max-height: 85vh; background: white; z-index: 999999;
    border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.4);
    padding: 24px; font-family: -apple-system, sans-serif;
    display: flex; flex-direction: column; border: 1px solid #dbdbdb;
  `;

  modal.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h2 style="margin: 0; font-size: 20px; color: #262626; font-weight: 800;">InstaTracker v2.0</h2>
      <button id="close-insta-modal" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #8e8e8e;">&times;</button>
    </div>
    <div id="setup-view">
      <p style="font-size: 14px; color: #262626; margin-bottom: 20px;">Clique abaixo para iniciar a análise automática.</p>
      <button id="start-analysis-btn" style="width: 100%; padding: 12px; background-color: #0095f6; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Analisar Agora</button>
    </div>
    <div id="analysis-view" style="display: none; flex-direction: column; flex-grow: 1; overflow: hidden;">
      <div id="analysis-status" style="margin-bottom: 10px; font-size: 13px; text-align: center; background: #f8f9fa; padding: 8px; border-radius: 6px;"></div>
      <div id="analysis-results" style="overflow-y: auto; flex-grow: 1; border-top: 1px solid #eee; padding-top: 10px;"></div>
    </div>
  `;

  document.body.appendChild(modal);
  const overlay = document.createElement('div');
  overlay.id = 'insta-tracker-overlay';
  overlay.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999998;";
  document.body.appendChild(overlay);

  document.getElementById('close-insta-modal').onclick = () => { modal.remove(); overlay.remove(); };
  document.getElementById('start-analysis-btn').onclick = () => {
    document.getElementById('setup-view').style.display = 'none';
    document.getElementById('analysis-view').style.display = 'flex';
    runInPageAnalysis();
  };
}

async function runInPageAnalysis() {
  const status = document.getElementById('analysis-status');
  const resultsDiv = document.getElementById('analysis-results');
  
  try {
    const getCookie = (n) => document.cookie.match('(^|;)\\s*' + n + '\\s*=\\s*([^;]+)')?.[2];
    const userId = getCookie('ds_user_id');
    if (!userId) throw new Error("Usuário não logado.");

    // Tentar encontrar o CSRF Token
    const csrfToken = getCookie('csrftoken');

    async function fetchList(type) {
      let list = [];
      let nextMaxId = null;
      let hasMore = true;
      
      // Nova abordagem: Usar a API de amizades (mais estável que GraphQL para 400 errors)
      const endpoint = type === 'followers' ? 'followers' : 'following';

      while (hasMore) {
        status.innerText = `Carregando ${type === 'followers' ? 'seguidores' : 'seguidos'}... ${list.length}`;
        
        let url = `https://www.instagram.com/api/v1/friendships/${userId}/${endpoint}/?count=50`;
        if (nextMaxId) url += `&max_id=${nextMaxId}`;

        const res = await fetch(url, {
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-Instagram-AJAX': '1',
            'X-CSRFToken': csrfToken || ''
          }
        });

        if (res.status === 429) throw new Error("Muitos pedidos. Aguarde 5 min.");
        if (!res.ok) throw new Error(`Erro ${res.status}. O Instagram limitou o acesso.`);

        const data = await res.json();
        const users = data.users || [];
        list = list.concat(users.map(u => ({ id: u.pk, username: u.username })));
        
        hasMore = !!data.next_max_id;
        nextMaxId = data.next_max_id;
        
        await new Promise(r => setTimeout(r, 1200));
      }
      return list;
    }

    const followers = await fetchList('followers');
    const following = await fetchList('following');

    const followerIds = new Set(followers.map(f => f.id.toString()));
    const notFollowingBack = following.filter(f => !followerIds.has(f.id.toString()));

    status.innerHTML = `Concluído! <b>${notFollowingBack.length}</b> não te seguem.`;
    
    if (notFollowingBack.length === 0) {
      resultsDiv.innerHTML = "<p style='text-align:center; color:green;'>Tudo certo!</p>";
    } else {
      notFollowingBack.forEach(user => {
        const item = document.createElement('div');
        item.style.cssText = "display:flex; justify-content:space-between; padding:10px; border-bottom:1px solid #eee; align-items:center;";
        item.innerHTML = `<span>@${user.username}</span> <a href="https://instagram.com/${user.username}" target="_blank" style="color:#0095f6; font-size:12px; font-weight:bold; text-decoration:none;">Perfil</a>`;
        resultsDiv.appendChild(item);
      });
    }
  } catch (err) {
    status.innerHTML = `<span style="color:red;">${err.message}</span>`;
  }
}

chrome.runtime.onMessage.addListener((m) => { if (m.action === "open_modal") createModal(); });

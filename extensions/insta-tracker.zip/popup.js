// Quando o popup (ícone) é clicado, ele envia uma mensagem para o content script na página
(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab.url && tab.url.includes("instagram.com")) {
      chrome.tabs.sendMessage(tab.id, { action: "open_modal" });
      // Fecha o pequeno popup do ícone para não atrapalhar
      window.close();
    } else {
      document.body.innerHTML = `
        <div style="width: 200px; padding: 15px; font-family: sans-serif; text-align: center;">
          <p style="font-size: 14px; color: #262626;">Por favor, abra o <b>Instagram</b> primeiro.</p>
          <a href="https://www.instagram.com" target="_blank" style="color: #0095f6; text-decoration: none; font-weight: bold;">Ir para o Instagram</a>
        </div>
      `;
    }
  } catch (err) {
    console.error(err);
  }
})();
